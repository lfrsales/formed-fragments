const { src, dest, parallel, watch } = require('gulp');

const zip = require('gulp-zip');

const config = require('./config.json');

function zipf() {
    return src('./**')
        .pipe(zip('test.zip'))
        .pipe(dest('./distribution'));
};

function deploy() {
	
	console.log(config.liferayHome);
	return zipf();
}

exports.deploy = deploy;
