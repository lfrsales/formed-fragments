console.group('Sample fragment');
console.log('fragmentElement', fragmentElement);
console.groupEnd();
